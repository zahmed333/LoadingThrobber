class FadingText {
    constructor(text) {
        this.text = text;
        this.fade = 0;
        this.fadeAmount = 1;
    }

    draw(x, y) {
        colorMode(RGB);
        fill(255, 255, 255, this.fade);
        textSize(100);
        text(this.text, width/9.5, height/9);
        textFont("Courier New");

        if (this.fade < 0) {
            this.fadeAmount = 1;
        }

        if (this.fade > 255) {
            this.fadeAmount = -10;
        }

        this.fade += this.fadeAmount;
    }
}
