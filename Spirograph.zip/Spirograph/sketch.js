let phase = 0;

let spinnerSize = 200;
let spinnerSpeed = 10;
let spinnerColor;

let yoff = 0.0;
let nextButton;
let reloadButton;
let fadingButton;
let searchButton;

const
    inner = [96, 105];
const
    outer = [24, 30, 32, 36, 40, 45, 48, 50, 52, 56, 60, 63, 64, 72, 75, 80, 84, 144, 150];

let fadingText;
let fadingTimer = 0;

var fixedGearTeeth = 96;
var rotatGearTeeth = 24;
var rotatInside = true;
const S = 120, angleRate = 0.05, colorRate = 0.02, distRate = 0.03;
let lastMillis = 0, anglePhase = 0.0, colorPhase = 0.0, distPhase = 0.0;

let mySound;

function preload() {
    mySound = loadSound('Crep.mp3');
}
function pickSettings() {
    rotatInside = random(1) < 0.5;
    let pickFixed;
    let pickRotor;
    if (rotatInside) {
        pickFixed = int(random(inner.length));
        fixedGearTeeth = inner[pickFixed];
        pickRotor = int(random(outer.length - 2));
        rotatGearTeeth = outer[pickRotor];
    } else {
        pickFixed = int(random(outer.length));
        fixedGearTeeth = outer[pickFixed];
        pickRotor = pickFixed;
        while (pickRotor === pickFixed)
            pickRotor = int(random(outer.length));
        rotatGearTeeth = outer[pickRotor];
    }

    anglePhase = random(TWO_PI);
    colorPhase = random(TWO_PI);
    distPhase = random(TWO_PI);

}
function setup() {
    createCanvas(windowWidth, windowHeight);
    nextButton = createButton('Next ➡️');
    reloadButton = createButton('🔄 Reload');
    searchButton = createButton('🔍 Search');

    fadingButton = createButton('Load Faster ⏩');


    phase = 0;
    pickSettings();
}

function gcd(a, b) {
    return b === 0 ? a : gcd(b, a % b);
}
function drawHypothyroid(a, b, h, phase) {
    // set up loop parameters
    var divisor = gcd(a, b);
    var loops = abs(a - b) / divisor;
    var steps = S * loops;

    // derived constants
    var scale = width * 0.5 / max(a, 2 * b - a);
    var Ra = scale * (a - b);
    var Rb = scale * h;

    // initial theta values
    var ta0 = 0.0;
    var tb0 = TWO_PI * phase;

    // delta theta per step
    var dta = TWO_PI * (b / divisor) / steps;
    var dtb = dta * (a - b) / b;

    // draw the shape
    beginShape();
    for (var step = 0; step < steps; ++step) {
        var ta = ta0 + step * dta;
        var tb = tb0 + step * dtb;
        var x = Ra * cos(ta) + Rb * cos(tb) + width * 0.5;
        var y = Ra * sin(ta) - Rb * sin(tb) + height * 0.5;
        vertex(x, y);
    }
    endShape(CLOSE);

    noFill();
    stroke(0, 0, 1, 1);
}
function drawEpicycloid(a, b, h, phase) {
    // set up loop parameters
    var divisor = gcd(a, b);
    var loops = abs(a + b) / divisor;
    var steps = S * loops;

    // derived constants
    var scale = width * 0.5 / (a + 2 * b);
    var Ra = scale * (a + b);
    var Rb = scale * h;

    // initial theta values
    var ta0 = 0.0;
    var tb0 = TWO_PI * phase;

    // delta theta per step
    var dta = TWO_PI * (b / divisor) / steps;
    var dtb = dta * (a + b) / b;

    // draw the shape
    beginShape();
    for (var step = 0; step < steps; ++step) {
        var ta = ta0 + step * dta;
        var tb = tb0 + step * dtb;
        var x = Ra * cos(ta) + Rb * cos(tb) + width * 0.5;
        var y = Ra * sin(ta) - Rb * sin(tb) + height * 0.5;
        vertex(x, y);
    }
    endShape(CLOSE);

    noFill();
    stroke(0, 0, 1, 1);
}

function bothDraw() {

        colorMode(RGB);
    if (phase !== 3) {
        background(random(255 / 15));
    }
        spinnerColor = color(random(33), random(100, 150), random(200, 243));

        let step = frameCount % (spinnerSpeed * random(7.24, 7.25));
        let angle = map(step, 0, spinnerSpeed * 7.25, 0, TWO_PI);

        push();
        translate(width / 2, height / 2);
        rotate(angle);
        noFill();
        stroke(spinnerColor);
        strokeWeight(spinnerSize / 10);
        strokeCap(SQUARE);
        arc(0, 0, spinnerSize - (spinnerSize / 20), spinnerSize - (spinnerSize / 20), 0, PI + HALF_PI, OPEN);
        pop();


    // measure time step in seconds
    var curMillis = millis();
    var dt = 0.001 * (curMillis - lastMillis);
    lastMillis = curMillis;
    colorMode(HSB, 1.0, 1.0, 1.0, 1.0);

    //colorMode(RGB);
    //background(random(255/15));
    colorMode(HSB, 1.0, 1.0, 1.0, 1.0);
    //background((colorPhase + 0.333333) % 1, 1, 0.25);
    stroke((colorPhase) % 1, 1, 1, 1);
    strokeWeight(2.0);
    //fill((colorPhase + 0.666667) % 1, 1, 0.5);
    noFill();
    if (rotatInside)
        drawHypothyroid(fixedGearTeeth, rotatGearTeeth, rotatGearTeeth * (0.5 + 0.45 * sin(TWO_PI * distPhase)), anglePhase);
    else
        drawEpicycloid(fixedGearTeeth, rotatGearTeeth, rotatGearTeeth * (0.5 + 0.45 * sin(TWO_PI * distPhase)), anglePhase);

    anglePhase += angleRate * dt;
    distPhase += distRate * dt;
    colorPhase += colorRate * dt;

}

function draw() {
    if (phase === 0) {
        landingPage();
        landingPageButtonSearch();
    }
    else if (phase === 1) {
        searchPage();
        reloadButton.position(0, 0);

        fadingButton.position(width/2.25, height/1.5);
        nextHandler();
    }
    else if (phase === 2) {
        bothDraw();
        reloadButton.position(0,0);
        nextHandler();
    }

    else if (phase === 3) {
        bothDraw();
        reloadButton.position(0,0);
        nextHandler();
    }

    else if (phase === 4) {
        searchPage();
        reloadButton.position(0,0);
        nextHandler();
    }

    else if (phase === 5) {
        searchPage();
        reloadButton.position(0,0);
        nextHandler();
    }


// make a function to restart the sketch
    function restart() {
        phase = 0;
        reloadButton.remove();
        nextButton.remove();
        fadingButton.remove();
        setup();
        draw();
    }

    fadingButton.mousePressed(activateFadingText);
    fadingButton.size(250, 50);
    fadingButton.style("font-family", "Courier New");
    fadingButton.style("font-size", "24px");
    fadingButton.style('background-color', 'beige');
    fadingButton.style('border-radius', '10px');
    fadingButton.style('border', 'none');
    fadingButton.style('box-shadow', '0 0 10px 0 rgba(50,10,50,0.5)');
    if (fadingText && fadingTimer < 9650) {
        fadingText.draw(100, 100);
        fadingTimer += deltaTime;
    }

    reloadButton.mousePressed(restart);
    reloadButton.size(150, 50);
    reloadButton.style("font-family", "Courier New");
    reloadButton.style("font-size", "24px");
    reloadButton.style('background-color', 'beige');
    reloadButton.style('border-radius', '10px');
    reloadButton.style('border', 'none');
    reloadButton.style('box-shadow', '0 0 10px 0 rgba(50,10,50,0.5)');


    function phaseOne() {
        spinnerSize = 200;
        phase = 1;
        searchButton.remove();
        mySound.play();
    }

    function phaseTwo() {
        spinnerSize = 200;
        phase = 2;
        background(255);
        searchButton.remove();
    }

    function phaseThree() {
        spinnerSize = 200;
        background(255);
        phase = 3;
    }

    function phaseFour() {
        phase = 4;
        spinnerSize = 500;
    }

    function phaseFive() {
        phase = 5;
        spinnerSize = random(1500);
    }

    function searchPage() {
        colorMode(RGB);
        background(random(255/15));

        spinnerColor = color(random(33), random(100,150), random(200, 243));

        let step = frameCount % (spinnerSpeed * random(7.24, 7.25));
        let angle = map(step, 0, spinnerSpeed * 7.25, 0, TWO_PI);

        push();
        translate(width / 2, height / 2);
        rotate(angle);
        noFill();
        stroke(spinnerColor);
        strokeWeight(spinnerSize / 10);
        strokeCap(SQUARE);
        arc(0, 0, spinnerSize - (spinnerSize / 20), spinnerSize - (spinnerSize / 20), 0, PI + HALF_PI, OPEN);
        pop();
    }
    function nextHandler() {
        //next button
        nextButton.size(150, 50);
        nextButton.position(width - width/10, 0);
        //do an if statement with a random condition
        if (random(100) > 80) {
            nextButton.mousePressed(phaseThree);
        }
        else if (random(100) > 60) {
            nextButton.mousePressed(phaseTwo);
        }
        else if(random(100) > 40) {
            nextButton.mousePressed(phaseFour);
        }
        else if(random(100) > 20) {
            nextButton.mousePressed(phaseFive);
            if (phase === 5)
                spinnerSize = random(1500);
        }

        nextButton.style("font-family", "Courier New");
        nextButton.style("font-size", "24px");
        nextButton.style('background-color', 'beige');
        nextButton.style('border-radius', '10px');
        nextButton.style('border', 'none');
        nextButton.style('box-shadow', '0 0 10px 0 rgba(50,10,50,0.5)');
    }


    function landingPageButtonSearch() {
        searchButton.size(235, 150);
        searchButton.style("font-family", "Courier New");
        searchButton.style("font-size", "48px");
        searchButton.position((width / 2) - width / 15, height / 2);
        searchButton.mousePressed(phaseOne);
        searchButton.style('background-color', 'beige');
        searchButton.style('border-radius', '30px');
        searchButton.style('border', 'none');
        searchButton.style('box-shadow', '0 0 10px 0 rgba(50,10,50,0.5)');
    }
    function landingPage() {
        background(255);
        fill(0);
        beginShape();
        let xoff = yoff;
        for (let x = 0; x <= width; x += 5) {
            let y = map(noise(xoff, yoff), 0, 1, 200, 300);
            vertex(x, y);
            xoff += 0.07;
        }
        yoff += 0.02;
        vertex(width, height);
        vertex(0, height);
        endShape(CLOSE);
    }
}

function activateFadingText() {
    fadingText = new FadingText("Thank you for being patient,\nwe are expediting your search!");
    fadingTimer = 0;
}

function mousePressed() {
    pickSettings();
}